# All Commands BlackMafia


⭕No 1
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/World
cd World
python2 Cloning.py

User: Black
pass: Mafia

